package com.niit.shopingcart.controller;

import org.springframework.stereotype.Controller;

@Controller
public class RegistrationController {

//	@RequestMapping("home")
//	public String home(){
//		return "index";
//	}
}